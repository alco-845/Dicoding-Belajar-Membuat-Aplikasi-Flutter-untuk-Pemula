# final_project

Final project for submission dicoding

Criteria Final Project :
- Stateless Widget =>  items in main_screen.dart is using stateless widget

- Stateful Widget =>  like and dislike button in detail_screen.dart is using statefull widget

- At least have two pages => 2, main screen and detail screen

- Responsive UI => I think yes(?)

- Don't have the same UI as the codelab project => Absolutely yes
