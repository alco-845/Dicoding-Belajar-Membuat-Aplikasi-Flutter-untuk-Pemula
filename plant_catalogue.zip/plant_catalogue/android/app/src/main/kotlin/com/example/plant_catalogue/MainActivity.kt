package com.example.plant_catalogue

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
